CREATE TABLE `cpl_terms` (  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(200) NOT NULL DEFAULT '',  `slug` varchar(200) NOT NULL DEFAULT '',  `term_group` bigint(10) NOT NULL DEFAULT '0',  PRIMARY KEY (`term_id`),  UNIQUE KEY `slug` (`slug`),  KEY `name` (`name`)) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `cpl_terms` DISABLE KEYS */;
INSERT INTO `cpl_terms` VALUES('1', 'Uncategorized', 'uncategorized', '0');
INSERT INTO `cpl_terms` VALUES('4', 'Meeting', 'meeting', '0');
INSERT INTO `cpl_terms` VALUES('5', 'Menu 1', 'menu-1', '0');
INSERT INTO `cpl_terms` VALUES('6', 'News', 'news', '0');
INSERT INTO `cpl_terms` VALUES('7', 'post-format-link', 'post-format-link', '0');
/*!40000 ALTER TABLE `cpl_terms` ENABLE KEYS */;
