CREATE TABLE `cpl_duplicator_packages` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(250) NOT NULL,  `hash` varchar(50) NOT NULL,  `status` int(11) NOT NULL,  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  `owner` varchar(60) NOT NULL,  `package` mediumblob NOT NULL,  PRIMARY KEY (`id`),  KEY `hash` (`hash`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `cpl_duplicator_packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpl_duplicator_packages` ENABLE KEYS */;
