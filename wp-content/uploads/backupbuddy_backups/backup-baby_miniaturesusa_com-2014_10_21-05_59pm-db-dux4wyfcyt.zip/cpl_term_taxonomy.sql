CREATE TABLE `cpl_term_taxonomy` (  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',  `taxonomy` varchar(32) NOT NULL DEFAULT '',  `description` longtext NOT NULL,  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',  `count` bigint(20) NOT NULL DEFAULT '0',  PRIMARY KEY (`term_taxonomy_id`),  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),  KEY `taxonomy` (`taxonomy`)) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `cpl_term_taxonomy` DISABLE KEYS */;
INSERT INTO `cpl_term_taxonomy` VALUES('1', '1', 'category', '', '0', '0');
INSERT INTO `cpl_term_taxonomy` VALUES('4', '4', 'category', '', '0', '3');
INSERT INTO `cpl_term_taxonomy` VALUES('5', '5', 'nav_menu', '', '0', '9');
INSERT INTO `cpl_term_taxonomy` VALUES('6', '6', 'category', '', '0', '1');
INSERT INTO `cpl_term_taxonomy` VALUES('7', '7', 'post_format', '', '0', '0');
INSERT INTO `cpl_term_taxonomy` VALUES('8', '8', 'post_format', '', '0', '1');
/*!40000 ALTER TABLE `cpl_term_taxonomy` ENABLE KEYS */;
